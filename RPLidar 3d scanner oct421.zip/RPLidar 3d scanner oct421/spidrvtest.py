    #import the library
import time
from spidriver import SPIDriver
count=0
anglestep=0.02197265625 #degrees per count
s = SPIDriver("/dev/ttyUSB0") # change for your port
s.sel()    # start command
s.seta(1)
while count <10000:
    
    s.sel()    # start command
    #s.write([0x9f]) # command 9F is READ JEDEC ID
    time.sleep(.1)
    vread=s.read(2)
    #summed=int.from_bytes(vread, "big")% (2**14)
    summed=((int.from_bytes(vread, "big")<<2)>>1)%(2**14)
    #print(list(vread),"  ",summed*anglestep) # read next 3 bytes[239, 64, 24]
    print(summed*anglestep)
    count +=1
    s.unsel()                  # end command