    #import the library
import time
from scanner_support_functions import anglesensorHW


spi = anglesensorHW(0,0,1)
count=0
while count<10000:
    angle=spi.getangle()
    
    print('angle: ',(angle), end='\r')
   
    count +=1
spi.close()

